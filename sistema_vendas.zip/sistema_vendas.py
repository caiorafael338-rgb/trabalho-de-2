from datetime import datetime
import uuid

# --- 1. CLASSE FIDELIDADE ---
class Fidelidade:
    def __init__(self, cliente_id):
        self.id = uuid.uuid4()
        self.cliente_id = cliente_id
        self.cashback_acumulado = 0.0
        self.pontos = 0
        self.nivel = "Bronze"

    def _atualizar_nivel(self):
        if self.pontos >= 5000:
            self.nivel = "Ouro"
        elif self.pontos >= 1000:
            self.nivel = "Prata"
        else:
            self.nivel = "Bronze"

    def gerar_pontuacao(self, valor_compra):
        if valor_compra >= 50.00:
            pontos_ganhos = int(valor_compra / 10)
            self.pontos += pontos_ganhos
            self._atualizar_nivel()
            return pontos_ganhos
        return 0

    def gerar_cashback(self, valor_compra):
        taxa = 0.05
        cashback_ganho = valor_compra * taxa
        self.cashback_acumulado += cashback_ganho
        return cashback_ganho

# --- 2. CLASSES PRODUTO E ESTOQUE ---
class Produto:
    def __init__(self, nome, preco, descricao, estoque_inicial):
        self.id = uuid.uuid4()
        self.nome = nome
        self.preco = preco
        self.descricao = descricao
        self.estoque = estoque_inicial
        self.LIMITE_ALERTA = 10

    def remover_estoque(self, quantidade):
        if self.estoque >= quantidade:
            self.estoque -= quantidade
            if self.estoque <= self.LIMITE_ALERTA:
                self.emitir_alerta_reposicao()
            return True
        return False

    def adicionar_estoque(self, quantidade):
        self.estoque += quantidade

    def emitir_alerta_reposicao(self):
        print(f"🚨 ALERTA DE ESTOQUE BAIXO: Produto '{self.nome}' com apenas {self.estoque} unidades.")

# --- 3. CLASSE CLIENTE ---
class Cliente:
    def __init__(self, nome, email, tipo_cliente='Comum'):
        self.id = uuid.uuid4()
        self.nome = nome
        self.email = email
        self.tipo_cliente = tipo_cliente
        self.data_cadastro = datetime.now()
        self.fidelidade = Fidelidade(self.id)

    def __str__(self):
        return f'Cliente: {self.nome} | Status: {self.tipo_cliente} | Nível: {self.fidelidade.nivel}'

# --- 4. CLASSES CARRINHO E ITEM CARRINHO ---
class ItemCarrinho:
    def __init__(self, produto, quantidade):
        self.produto = produto
        self.quantidade = quantidade
        self.preco_unitario = produto.preco
        self.subtotal = produto.preco * quantidade

class Carrinho:
    def __init__(self, cliente):
        self.cliente = cliente
        self.itens = []
        self.desconto = 0.0

    def adicionar_item(self, produto, quantidade):
        if produto.estoque >= quantidade:
            item = ItemCarrinho(produto, quantidade)
            self.itens.append(item)
            return True
        return False

    def calcular_subtotal(self):
        return sum(item.subtotal for item in self.itens)

    def aplicar_desconto_vip(self, porcentagem=0.10):
        if self.cliente.tipo_cliente == 'VIP' and self.desconto == 0:
            valor_desconto = self.calcular_subtotal() * porcentagem
            self.desconto = valor_desconto

    def aplicar_cupom(self, cupom):
        if cupom.usado:
            return False
        self.desconto += cupom.valor_desconto
        cupom.usado = True
        return True

    def valor_total(self):
        return self.calcular_subtotal() - self.desconto

    def finalizar_compra(self):
        if not self.itens:
            return None
        for item in self.itens:
            item.produto.remover_estoque(item.quantidade)
        valor_total = self.valor_total()
        desconto_aplicado = self.desconto
        pedido = Pedido(self.cliente, self.itens, valor_total, desconto_aplicado)
        self.itens = []
        self.desconto = 0.0
        return pedido

# --- 5. CLASSES PAGAMENTO E CUPOM ---
class Pagamento:
    def __init__(self, tipo, valor):
        self.id = uuid.uuid4()
        self.tipo_pagamento = tipo
        self.valor_pago = valor
        self.status = 'Pendente'

class Cupom:
    def __init__(self, codigo, valor_desconto, tipo='Valor'):
        self.codigo = codigo
        self.valor_desconto = valor_desconto
        self.tipo = tipo
        self.data_validade = datetime.now().replace(year=datetime.now().year + 1)
        self.usado = False

# --- 6. CLASSE PEDIDO ---
class Pedido:
    def __init__(self, cliente, itens, valor_total, desconto_aplicado):
        self.id = uuid.uuid4()
        self.cliente = cliente
        self.itens = itens
        self.valor_total = valor_total
        self.desconto_aplicado = desconto_aplicado
        self.data_pedido = datetime.now()
        self.status = 'Em Processamento'
        self.pagamento = None

    def processar_pagamento(self, pagamento):
        self.pagamento = pagamento
        self.pagamento.status = 'Aprovado'
        cashback_ganho = self.cliente.fidelidade.gerar_cashback(self.valor_total)
        pontos_ganhos = self.cliente.fidelidade.gerar_pontuacao(self.valor_total)

    def atualizar_status(self, novo_status):
        if novo_status in ['Em Processamento', 'Enviado', 'Entregue']:
            self.status = novo_status

# --- 7. CLASSE GERENCIAMENTO ---
class GerenciadorVendas:
    def __init__(self):
        self.pedidos_finalizados = []

    def adicionar_pedido(self, pedido):
        self.pedidos_finalizados.append(pedido)

    def gerar_relatorio_vendas(self):
        total_receita = sum(p.valor_total for p in self.pedidos_finalizados)
        total_pedidos = len(self.pedidos_finalizados)
        produtos_vendidos = {}
        for pedido in self.pedidos_finalizados:
            for item in pedido.itens:
                produtos_vendidos[item.produto.nome] = produtos_vendidos.get(item.produto.nome, 0) + item.quantidade
